# Cotton vs. Polyester Blend Calculator

**Student:** Syed Kafeel Ahmed Shah  
**Roll No.:** 25TE006  
**Department:** Textile Engineering, Mehran University of Engineering and Technology (MUET), Jamshoro  
**Course:** AI234 – Artificial Intelligence | 3rd Semester  
**Instructor:** Dr. Pardeep Kumar Gianchandani

## Project overview
This Streamlit web application estimates the raw fibre-material cost per metre for a cotton/polyester blend. Users select the cotton percentage with a slider; the polyester percentage is calculated automatically so the blend always totals 100%. Users can enter fibre prices, fabric GSM, fabric width and processing cost. The app displays blend cost per kilogram, raw material cost per metre, estimated total cost per metre, and simple comfort/durability indicators.

## Features
- Cotton blend slider (0–100%); polyester percentage is calculated automatically.
- Editable cotton and polyester fibre prices in PKR/kg.
- Editable fabric GSM, width and processing/conversion cost.
- Raw fibre-material cost per metre and estimated total cost per metre.
- Simple illustrative comfort and durability indicators.
- Blend pie chart, cost breakdown and comparison table for common blend ratios.
- Formula explanation and a Limitations & Responsible Use note.

## Calculation method
Let C be cotton percentage and P be polyester percentage (C + P = 100).

1. Blend fibre cost (PKR/kg) = (C/100 × cotton price) + (P/100 × polyester price)
2. Fabric width (m) = width (inches) × 0.0254
3. Fabric mass (kg/m) = GSM × width (m) ÷ 1000
4. Raw material cost (PKR/m) = blend fibre cost (PKR/kg) × fabric mass (kg/m)
5. Estimated total cost (PKR/m) = raw material cost + processing cost per metre

Comfort and durability are transparent, illustrative indicators:
- Comfort = 5 + 4 × cotton fraction
- Durability = 5 + 4 × polyester fraction

These indicators are educational assumptions, not measured textile properties or predictions from a trained ML model.

## Run locally
1. Install Python 3.10 or later.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run:
   ```bash
   streamlit run app.py
   ```

## GitHub and Streamlit Community Cloud deployment
1. Create a **public** GitHub repository.
2. Upload `app.py`, `requirements.txt` and `README.md`.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Select the repository, branch and `app.py`, then deploy.
5. Test the public app URL and add both the GitHub repository URL and live Streamlit URL to Slide 5 of the presentation before submission.

## Responsible use and limitations
The tool uses user-entered assumptions and simplified formulas. It does not account for yarn count, yarn/fabric construction, fibre grade, spinning losses, weaving/knitting losses, finishing, taxes, overheads or changing market rates unless included in the user's inputs. The comfort and durability indicators are not laboratory results. Validate inputs and confirm commercial costing with mill data before relying on the result. No personal data is collected or stored by this app.

## Assignment submission
PowerPoint filename: `25TE006_AI234_TextileAI.pptx`  
Submission deadline stated in the assignment: **06 December 2026**.
