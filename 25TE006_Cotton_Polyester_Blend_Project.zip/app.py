import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(
    page_title="Cotton vs. Polyester Blend Calculator",
    page_icon="🧵",
    layout="wide"
)

st.title("🧵 Cotton vs. Polyester Blend Calculator")
st.caption("AI234 Capstone Project | Department of Textile Engineering | MUET Jamshoro")

st.markdown("""
Estimate the **raw fibre-material cost per metre** of a cotton/polyester blend
and compare its basic comfort and durability characteristics.
""")

with st.sidebar:
    st.header("Project information")
    st.write("**Student:** Syed Kafeel Ahmed Shah")
    st.write("**Roll No.:** 25TE006")
    st.write("**Course:** AI234 – Artificial Intelligence")
    st.divider()
    st.subheader("Blend composition")
    cotton_pct = st.slider("Cotton (%)", min_value=0, max_value=100, value=60, step=5)
    polyester_pct = 100 - cotton_pct
    st.metric("Polyester (%)", f"{polyester_pct}%")
    st.caption("The two percentages always add up to 100%.")

st.subheader("1. Enter material and fabric details")
col1, col2 = st.columns(2)
with col1:
    cotton_price = st.number_input(
        "Cotton fibre price (PKR/kg)", min_value=0.0, value=650.0, step=25.0
    )
    polyester_price = st.number_input(
        "Polyester fibre price (PKR/kg)", min_value=0.0, value=500.0, step=25.0
    )
    processing_cost = st.number_input(
        "Processing / conversion cost (PKR per metre)",
        min_value=0.0, value=35.0, step=5.0
    )
with col2:
    fabric_gsm = st.number_input(
        "Fabric GSM (g/m²)", min_value=1.0, value=180.0, step=5.0
    )
    fabric_width = st.number_input(
        "Fabric width (inches)", min_value=1.0, value=60.0, step=1.0
    )
    st.caption("Prices and processing cost are editable assumptions. Enter your own market or mill values.")

# Core calculations
blend_cost_per_kg = (
    cotton_pct / 100 * cotton_price
    + polyester_pct / 100 * polyester_price
)
width_m = fabric_width * 0.0254
fabric_mass_kg_per_m = fabric_gsm * width_m / 1000
raw_material_cost_per_m = blend_cost_per_kg * fabric_mass_kg_per_m
estimated_total_cost_per_m = raw_material_cost_per_m + processing_cost

# Transparent, illustrative rating rules (not laboratory measurements)
comfort_rating = 5 + 4 * cotton_pct / 100
durability_rating = 5 + 4 * polyester_pct / 100

st.subheader("2. Estimated results")
m1, m2, m3, m4 = st.columns(4)
m1.metric("Cotton / Polyester", f"{cotton_pct}% / {polyester_pct}%")
m2.metric("Blend fibre cost", f"PKR {blend_cost_per_kg:,.2f}/kg")
m3.metric("Raw material cost", f"PKR {raw_material_cost_per_m:,.2f}/m")
m4.metric("Estimated total cost", f"PKR {estimated_total_cost_per_m:,.2f}/m")

st.subheader("3. Comfort and durability indicators")
r1, r2 = st.columns(2)
with r1:
    st.write("**Estimated comfort**")
    st.progress(int(round(comfort_rating * 10)))
    st.metric("Comfort indicator", f"{comfort_rating:.1f} / 10")
    st.caption("The illustrative score increases with cotton percentage.")
with r2:
    st.write("**Estimated durability**")
    st.progress(int(round(durability_rating * 10)))
    st.metric("Durability indicator", f"{durability_rating:.1f} / 10")
    st.caption("The illustrative score increases with polyester percentage.")

st.subheader("4. Blend and cost breakdown")
chart_col, table_col = st.columns(2)
with chart_col:
    fig, ax = plt.subplots()
    ax.pie(
        [cotton_pct, polyester_pct],
        labels=["Cotton", "Polyester"],
        autopct="%1.0f%%",
        startangle=90
    )
    ax.set_title("Blend composition")
    st.pyplot(fig, clear_figure=True)
with table_col:
    breakdown = pd.DataFrame({
        "Cost component": ["Raw fibre material", "Processing / conversion", "Estimated total"],
        "Cost (PKR per metre)": [
            raw_material_cost_per_m, processing_cost, estimated_total_cost_per_m
        ]
    })
    st.dataframe(breakdown, use_container_width=True, hide_index=True)

st.subheader("5. Comparison of possible blend ratios")
comparison_rows = []
for c in [0, 25, 50, 60, 75, 100]:
    p = 100 - c
    cost_kg = c / 100 * cotton_price + p / 100 * polyester_price
    raw_cost = cost_kg * fabric_mass_kg_per_m
    comparison_rows.append({
        "Cotton (%)": c,
        "Polyester (%)": p,
        "Raw material cost (PKR/m)": round(raw_cost, 2),
        "Comfort indicator (/10)": round(5 + 4 * c / 100, 1),
        "Durability indicator (/10)": round(5 + 4 * p / 100, 1)
    })
st.dataframe(pd.DataFrame(comparison_rows), use_container_width=True, hide_index=True)

st.info(
    "Interpretation: increasing cotton share raises the comfort indicator in this "
    "simple model, while increasing polyester share raises the durability indicator. "
    "Actual performance depends on yarn construction, fabric structure, finishing, "
    "fibre quality and test conditions."
)

with st.expander("How are the calculations made?"):
    st.latex(r"\text{Blend cost (PKR/kg)} = "
             r"\frac{C}{100}P_C + \frac{P}{100}P_P")
    st.latex(r"\text{Fabric mass (kg/m)} = "
             r"\frac{GSM \times Width(m)}{1000}")
    st.latex(r"\text{Raw material cost (PKR/m)} = "
             r"\text{Blend cost (PKR/kg)} \times \text{Fabric mass (kg/m)}")
    st.write("Estimated total cost per metre = raw material cost + processing cost.")

st.subheader("Limitations & Responsible Use")
st.write("""
- This is an educational estimation tool, not a certified costing or fabric-testing system.
- Fibre prices, fabric GSM, width and processing cost are user-entered assumptions and may not reflect current market rates.
- Comfort and durability scores are simple illustrative indicators based on blend percentage; they are not produced by laboratory testing or a trained machine-learning model.
- The application does not collect or store personal data. Do not enter confidential company information.
- Verify calculations, prices and fabric specifications with reliable mill records before making commercial decisions.
""")

st.caption("Developed for AI234 – Individual Capstone Web Application Project | Roll No. 25TE006")
